﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HashCodeOnline2020
{
    public class LibResult
    {
        public int id { get; set; }
        public List<int> Books { get; set; }
    }
}
